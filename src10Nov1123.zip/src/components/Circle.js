import React, { Component } from 'react'

class Circle extends Component {
    render() {
        return(
            <>
            {this.props.player}
            </>
        )
    }
}
export default Circle

